"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// data.json
var require_data = __commonJS({
  "data.json"(exports, module2) {
    module2.exports = {
      data: []
    };
  }
});

// src/samples/handler.ts
var handler_exports = {};
__export(handler_exports, {
  samples: () => samples
});
module.exports = __toCommonJS(handler_exports);

// src/core/middlewares/proxy-event.middleware.ts
var ProxyEventMiddleware = class {
  body;
  params;
  event;
  constructor(event) {
    this.event = event;
    const { body, pathParameters } = event;
    if (body)
      this.body = JSON.parse(body);
    if (pathParameters)
      this.params = pathParameters;
    console.log({ body: this.body, params: this.params, event: this.event });
  }
};

// src/samples/domain/entities/sample.entity.ts
var SampleEntity = class {
  id;
  name;
};

// src/samples/domain/entities/sample.model.ts
var SampleModel = class extends SampleEntity {
  constructor(sample) {
    super();
    this.id = sample == null ? void 0 : sample.id;
    this.name = sample == null ? void 0 : sample.name;
  }
};

// src/samples/application/use-cases/create-sample.usecase.ts
var CreateSampleUsecase = class {
  constructor(repository) {
    this.repository = repository;
  }
  async execute(data) {
    const { id, name } = data;
    const sample = new SampleModel();
    sample.id = id;
    sample.name = name;
    return this.repository.create(sample);
  }
};

// src/core/repositories/generic-provider.repository.ts
var GenericProviderRepository = class {
};

// src/samples/domain/repositories/sample-provider.repository.ts
var SampleProviderRepository = class extends GenericProviderRepository {
};

// src/samples/domain/repositories/sample-local.repository.ts
var import_data = __toESM(require_data());
var SampleLocalRepository = class extends SampleProviderRepository {
  items = import_data.default.data;
  async create(data) {
    this.items.push(data);
    return true;
  }
  async delete(id) {
    this.items.filter((item) => item.id !== id);
    return true;
  }
  async find(id) {
    const todo = this.items.find((item) => item.id == id);
    if (!todo)
      return null;
    return todo;
  }
  async findAll() {
    return this.items;
  }
  async update(id, data) {
    const sample = this.items.find((item) => item.id == id);
    if (!sample)
      return false;
    sample.id = data.id;
    sample.name = data.name;
    return true;
  }
  async updateField(id, key, value) {
    const sample = this.items.find((item) => item.id == id);
    if (!sample)
      return false;
    sample[key] = value;
    return true;
  }
};

// src/samples/application/use-cases/find-sample.usecase.ts
var FindSampleUsecase = class {
  constructor(repository) {
    this.repository = repository;
  }
  async execute(id) {
    return this.repository.find(id);
  }
};

// src/samples/application/use-cases/findall-sample.usecase.ts
var FindallSampleUsecase = class {
  constructor(repository) {
    this.repository = repository;
  }
  async execute() {
    return this.repository.findAll();
  }
};

// src/samples/application/use-cases/update-sample.usecase.ts
var UpdateSampleUsecase = class {
  constructor(repository) {
    this.repository = repository;
  }
  async execute(id, data) {
    return this.repository.update(id, data);
  }
};

// src/samples/application/use-cases/delete-sample.usecase.ts
var DeleteSampleUsecase = class {
  constructor(repository) {
    this.repository = repository;
  }
  async execute(id) {
    return this.repository.delete(id);
  }
};

// src/core/responses/send-response.service.ts
var SendResponseService = class {
  payload = {
    body: { message: null, success: true, result: null, statusCode: 200 /* OK */ }
  };
  response = { statusCode: 200 /* OK */, body: JSON.stringify(this.payload.body) };
  apiResponse(payload) {
    this.payload.body.statusCode = (payload == null ? void 0 : payload.statusCode) || 200 /* OK */;
    this.payload.body.success = (payload == null ? void 0 : payload.success) || true;
    this.payload.body.result = (payload == null ? void 0 : payload.result) || void 0;
    this.payload.body.message = payload.message;
    this.response.statusCode = this.payload.body.statusCode;
    this.response.body = JSON.stringify(this.payload.body);
    return this.response;
  }
};

// src/core/responses/error-response.service.ts
var ErrorResponseService = class {
  payload = {
    body: { message: "Internal server error", success: false, detail: null, statusCode: 500 /* INTERNAL_SERVER */ }
  };
  response = { statusCode: 500 /* INTERNAL_SERVER */, body: JSON.stringify(this.payload.body) };
  apiResponse(payload) {
    var _a;
    this.payload.body.statusCode = (payload == null ? void 0 : payload.statusCode) || 500 /* INTERNAL_SERVER */;
    this.payload.body.success = (payload == null ? void 0 : payload.success) || false;
    this.payload.body.message = ((_a = payload == null ? void 0 : payload.error) == null ? void 0 : _a.message) || (payload == null ? void 0 : payload.message);
    this.payload.body.detail = payload == null ? void 0 : payload.error.stack;
    this.response.statusCode = this.payload.body.statusCode;
    this.response.body = JSON.stringify(this.payload.body);
    return this.response;
  }
};

// src/samples/infrastructure/controllers/sample.controller.ts
var SampleController = class extends ProxyEventMiddleware {
  repository = new SampleLocalRepository();
  response = { send: new SendResponseService(), error: new ErrorResponseService() };
  result;
  constructor(event) {
    console.log("[SampleController.constructor]");
    super(event);
  }
  async selectResource() {
    console.log("[SampleController.selectResource]");
    switch (this.event.httpMethod) {
      case "GET":
        if (this.event.resource === "/samples") {
          return this.findAll();
        } else if (this.event.resource === "/samples/{id}") {
          return this.find(this.params.id);
        }
        break;
      case "POST":
        if (this.event.resource === "/samples") {
          return this.create(this.body.payload);
        }
        break;
      case "PUT":
        if (this.event.resource === "/samples/{id}") {
          return this.update(this.params.id, this.body.payload);
        }
        break;
      case "DELETE":
        if (this.event.resource === "/samples/{id}") {
          return this.delete(this.params.id);
        }
        break;
      default:
        return {
          statusCode: 500,
          body: JSON.stringify({ success: false, message: "Recurso no encontrado" })
        };
    }
  }
  async create(data) {
    console.log("[SampleController.create]", { data });
    try {
      const createSampleUsecase = new CreateSampleUsecase(this.repository);
      await createSampleUsecase.execute(data);
      return this.response.send.apiResponse({ message: "Sample created", statusCode: 201 /* CREATED */ });
    } catch (error) {
      return this.response.error.apiResponse({ error });
    }
  }
  async delete(id) {
    console.log("[SampleController.delete]", { id });
    try {
      const deleteSampleUsecase = new DeleteSampleUsecase(this.repository);
      this.result = await deleteSampleUsecase.execute(id);
      return this.response.send.apiResponse({ message: "Delete sample", result: this.result });
    } catch (error) {
      return this.response.error.apiResponse({ error });
    }
  }
  async find(id) {
    console.log("[SampleController.find]", { id });
    try {
      const findSampleUsecase = new FindSampleUsecase(this.repository);
      this.result = await findSampleUsecase.execute(id);
      return this.response.send.apiResponse({ message: "Single sample", result: this.result });
    } catch (error) {
      return this.response.error.apiResponse({ error });
    }
  }
  async findAll() {
    console.log("[SampleController.findAll]");
    try {
      const findallSampleUsecase = new FindallSampleUsecase(this.repository);
      this.result = await findallSampleUsecase.execute();
      return this.response.send.apiResponse({ message: "All samples", result: this.result });
    } catch (error) {
      return this.response.error.apiResponse({ error });
    }
  }
  async update(id, data) {
    console.log("[SampleController.update]", { id, data });
    try {
      const updateSampleUsecase = new UpdateSampleUsecase(this.repository);
      await updateSampleUsecase.execute(id, data);
      return this.response.send.apiResponse({ message: "Update sample", result: this.result });
    } catch (error) {
      return this.response.error.apiResponse({ error });
    }
  }
};

// src/samples/handler.ts
async function samples(event) {
  return new SampleController(event).selectResource();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  samples
});
